# EigenLayer
EigenLayer Testnet.... Софт на EigenLayer по этому гайду. https://teletype.in/@alphahunterss/EigenLayer

> В private_keys.txt вставьте приватники. На кошельках должен быть тестовый эфир в Goerli. (Минимум 0.05)

> В config.py настройте сон и процент, от эфира, который будет потрачен.

> pip install -r requirements.txt в консоль, чтобы установить зависимости

> Python 3.10+ 

-> Софт переводит ваш gETH в rETH и stETH, дальше кидает их в стейкинг юзая протокол EigenLayer. Остается только молиться на ретродроп в будущем.

# Media
telegram - t.me/tripleshizu

twitter - twitter.com/tripleshizu

tiktok - tiktok.com/iloveronaldo

> Если есть советы по коду напишите в лс @qqrwo - tg. Спасибо.

# Пока
